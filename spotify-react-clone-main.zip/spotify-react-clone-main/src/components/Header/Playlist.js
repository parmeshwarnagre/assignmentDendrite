import React from 'react';

export default function Playlist() {
  return (
    <nav className='flex'>
        <ul>
            <li className='mb-2'>
                <a href="#" className='text-link hover:text-white text-sm font-semibold'>
                    Dil
                </a>
            </li>
            <li className='mb-2'>
                <a href="#" className='text-link hover:text-white text-sm font-semibold'>
                    Sama
                </a>
            </li>
            <li className='mb-2'>
                <a href="#" className='text-link hover:text-white text-sm font-semibold'>
                    dil se
                </a>
            </li>
            
            
            
            
        </ul>
    </nav>

  )
  }